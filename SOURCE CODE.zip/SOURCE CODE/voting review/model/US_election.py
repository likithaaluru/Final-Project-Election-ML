import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from textblob import TextBlob

import numpy as np
import pickle
import itertools
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.metrics import accuracy_score, confusion_matrix

Trump_reviews = pd.read_csv('data/trump_data.csv', index_col=0)
Biden_reviews = pd.read_csv('data/biden_data.csv', index_col=0)

# Trump_reviews.head()
#
# Trump_reviews['text'][25]
#
# Biden_reviews['text'][500]
#
# TextBlob(Trump_reviews['text'][25]).sentiment
#
#
# TextBlob(Biden_reviews['text'][500]).sentiment


def polarity(review):
    return TextBlob(review).sentiment.polarity


Trump_reviews['polarity'] = Trump_reviews['text'].apply(polarity)
Biden_reviews['polarity'] = Biden_reviews['text'].apply(polarity)

# Trump_reviews.head()
#
# Biden_reviews.head()

Trump_reviews['Expression'] = np.where(Trump_reviews['polarity'] > 0, 'Positive', 'Negative')
Trump_reviews.loc[Trump_reviews.polarity == 0, 'Expression'] = 'Netural'
# Trump_reviews.head()

Biden_reviews['Expression'] = np.where(Biden_reviews['polarity'] > 0, 'Positive', 'Negative')
Biden_reviews.loc[Biden_reviews.polarity == 0, 'Expression'] = 'Netural'
# Biden_reviews.head()


def exp_graph(reviews, title):
    group = reviews.groupby('Expression').count()
    Pol_count = list(group['polarity'])
    Exp = list(group.index)

    group_list = list(zip(Pol_count, Exp))

    df = pd.DataFrame(group_list, columns=['Pol_count', 'Exp'])

    df['color'] = 'rgb(14,185,54)'
    df.loc[df.Exp == 'Netural', 'color'] = 'rgb(18,29,31)'
    df.loc[df.Exp == 'Negative', 'color'] = 'rgb(206,31,31)'

    # go.Figure(go.Bar(x=df['Pol_count'],
    #                  y=df['Exp'], orientation='h',
    #                  marker={'color': df['color']})).update_layout(title_text=title).show()

#
# Trump_reviews[Trump_reviews['polarity'] == 0].shape
#
# Biden_reviews[Biden_reviews['polarity'] == 0].shape

Trump_reviews.drop((Trump_reviews[Trump_reviews['polarity'] == 0]).index, inplace=True)
print(Trump_reviews.shape)
Biden_reviews.drop((Biden_reviews[Biden_reviews['polarity'] == 0]).index, inplace=True)
print(Biden_reviews.shape)
#
# Trump_reviews
#
# Biden_reviews

result = pd.concat([Trump_reviews, Biden_reviews], axis=0)

# result

df_x = result['text']
df_y = result['Expression']



tfidf_vectorizer = TfidfVectorizer(stop_words='english', max_df=0.7)

from sklearn.feature_extraction.text import TfidfVectorizer

tfidf_vectorizer = TfidfVectorizer(min_df=1, stop_words='english')

tfidf_train = tfidf_vectorizer.fit_transform(df_x)

pac = PassiveAggressiveClassifier(max_iter=50)
pac.fit(tfidf_train, df_y)
import pickle
pickle.dump(pac, open('vote1.pickle','wb'))
